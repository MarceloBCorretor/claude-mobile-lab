const VERSION='pinball-zumbi-v6';
const SHELL=["./", "./index.html", "./game.js", "./manifest.webmanifest", "./assets/ui/menu.webp", "./assets/ui/og-felipe.jpg", "./assets/ui/personagens.webp", "./assets/ui/thumb-fonte.webp", "./assets/felipe/empolgado.webp", "./assets/felipe/feliz.webp", "./assets/felipe/neutro.webp", "./assets/felipe/triste.webp", "./assets/felipe/vitoria.webp", "./assets/fase1/atirador.png", "./assets/fase1/barreira.png", "./assets/fase1/cereja.png", "./assets/fase1/flipper.png", "./assets/fase1/fundo.webp", "./assets/fase1/gelo.png", "./assets/fase1/girassol.png", "./assets/fase1/lancador.png", "./assets/fase1/lixeira.png", "./assets/fase1/lixeira2.png", "./assets/fase1/marcador.png", "./assets/fase1/pneu.png", "./assets/fase1/zumbi_34d.png", "./assets/fase1/zumbi_34e.png", "./assets/fase1/zumbi_andando.png", "./assets/fase1/zumbi_comendo.png", "./assets/fase1/zumbi_dano.png", "./assets/fase1/zumbi_frente.png", "./assets/icones/apple-touch-icon.png", "./assets/icones/icone-192.png", "./assets/icones/icone-512.png"];
self.addEventListener('install',e=>{e.waitUntil(caches.open(VERSION).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(Promise.all([caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==VERSION).map(k=>caches.delete(k)))),self.clients.claim()]))});
// Rede primeiro: com internet sempre pega a versão nova; sem internet usa o cache.
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET'||new URL(e.request.url).origin!==self.location.origin)return;
  e.respondWith(fetch(e.request).then(r=>{if(r.ok){const c=r.clone();caches.open(VERSION).then(ca=>ca.put(e.request,c))}return r}).catch(()=>caches.match(e.request)));
});
